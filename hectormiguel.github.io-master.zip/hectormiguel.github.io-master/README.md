<font color="#DAF7A6">
<hr>
-Service management -Consulting -Design -Development -Infrastructure -SysOp 
-Server -Networking -Hardware -Support -Training.</font>
<hr/>
<hr/>
<hr/>
***Hola! Bienvenido al BLOG, me alegra que estés Aquí.*** 
<hr/>
<hr/>
<hr/>
### <font color=" #DAF7A6">Instalar Pelican en OpenBSD.</font> ### 
Este nuevo articulo en Hector Miguel SysOp, tiene como objetivo instalar Pelican Web Site estatico.
<br/>
Lo primero es descargar Pelican del repositorio publico del sistema.
<br/>
El paquete tiene dependencia de Python, por lo que requiere su respectiva instalacion.
<br/>
<br/>
Agregando a Pelican en la lista de paquetes del Sistema Operativo.
<br/>
<font color="#9EFD38">$ pkg_add https://ftp.openbsd.org/pub/OpenBSD/6.x/packages/%a/pelican</font>
<br/>
Pos instalacion procedes en crear un nuevo proyecto, este iniciando la  gestion del directorio.
<br/>
<font color="#9EFD38">$ mkdir -p ~/projects/tu-web-site</font>
<br/>
Entrar al directorio del proyecto.
<br/>
<font color="#9EFD38">$ cd ~/projects/tu-web-site</font>
<br/>
Ahora gestionar el skeleto del proyecto via el comando:
<br/>
<font color="#9EFD38">$ pelican-quickstart</font>
<br>
Continuas aceptado los valores y usas el prefijo de su direccion Web. Ej. su-web.net
<br>
Ahora solo queda subir los archivos del proyecto a su Servidor Web, con el comando
<br/>
<font color="#9EFD38">$ rsync -avc --delete output/ /var/www/tu-web-site</font>
<br>
Listo!
<br/>
<br/>Edición compartida del: -Blog Personal de Hector Miguel Sysop-
<hr>
### <font color="#DAF7A6">Túnel de comunicación segura en Red Privada de Datos.</font> ### 
-VPN o Red Privada Virtual es, una Red donde existe un equipo servidor y usuarios nominados clientes remotos, este permite conexion segura mediante un tunel de encapsulamiento de datos que viajan entre si, llevando como metodo Autenticidad de autorización, integridad de los datos y confidiencialidad para la privacidad.
<br/> 
Una representacion textual es una empresa de sucursal, (1- Maquina Servidor VPN. Red-1 IP 169.254.1.1 Departamento de Computos. Sede Principal. =======tunel==== (2. + Internet. ====tunel===== (3- Maquina Cliente Remoto. (Sucursal). Red-2 IP 169.254.2.1. 
<br>
Si deseas saber más del manual de Infraestructura VPN. Escribir A: Consulting at Hector Miguel DotNet.
<br>Fuente: ~hms.
<hr>
### <font color="#DAF7A6">"Gusano Morris primer malware de la historia:</font> ### 
En el mes de Noviembre, surge el pionero Malware auto replicable, "El Gusano Morris".
Afecto internet, anteriormente ARPANET. Autor Robert Tappan Morris. #rtm.
No fue intencion afectar los ordenadores y hacer que funcionaran lentos" Robert Morris Jr.
<hr/>
<font color="#DAF7A6">"WOZ U" Proyecto de Sistema Educativo, diseñado para la programación de Software:</font>
  -Inicitiva inspirada en Steve Wozniak, co-fundador de Apple Computer. 
  <br>Fuente. -WOZ U-
<hr/>
### <font color="#DAF7A6">"KRACK" Vulnerabilidad encontrada en la seguridad estandar de WI-FI.</font> ###
-Permite al atacante acceder a redes de dipositivos interconectados a la Internet, a través del protocolo de acceso protegido WI-FI.
<br/>Fuente: -WIRED-
<hr/>
<hr/>
<font color="#DAF7A6">A sabienda del modelo de caracter altruista, es gratificante dirigime a usted en nombre de Hector Miguel Dot Net;
con la confianza en que la peticion sera acogida, obteniendo de esta parte, disponibilidad en Servicio de Asistencia Técnica en Sistemas & Computacion, contribuyendo así, al servicio curricular y gestion del mismo.<a href="https://paypal.me/HectorMiguel36/"> ---Haga aquí su aporte.---</a><br>En Transferencia tecnológica escribir a consulting at Hector Miguel Dot Net</font><hr/>
<hr/><hr/>
